crossover restricted to crossover hotspot in middle of network
