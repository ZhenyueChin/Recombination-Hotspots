This trial test the original Espinosa soto. Simply dumps the two sets of populations, for later analysis. 3 trials, 10 seeds each. No crossover
