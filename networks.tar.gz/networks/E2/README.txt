part E1: random crossover (for half the population)
